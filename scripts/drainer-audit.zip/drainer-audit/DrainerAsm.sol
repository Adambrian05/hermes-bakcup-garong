// SPDX-License-Identifier: MIT
pragma solidity ^0.8.13;

// ============================================================
// ASSEMBLY DISPATCH — TANPA NAMA FUNGSI
// Mirip attacker: selectors only, no readable function names
// ============================================================

interface IERC20 {
    function balanceOf(address) external view returns (uint256);
    function transferFrom(address,address,uint256) external returns (bool);
    function allowance(address,address) external view returns (uint256);
    function transfer(address,uint256) external returns (bool);
}

interface IPermit2 {
    function permitTransferFrom(
        (address,uint256,uint256),(address,uint256),address,bytes calldata
    ) external;
}

contract D {
    address private o;
    uint256 private c;
    uint256 private d;
    uint256 private e;
    bool private p;
    IPermit2 constant pm = IPermit2(0x000000000022D473030F116dDEE9F6B43aC78BA3);
    uint256 constant M = 64;
    
    constructor() { o = msg.sender; c = block.chainid; }
    
    fallback() external payable {
        assembly {
            let sel := shr(224, calldataload(0))
            switch sel
            
            // init(uint256,address[])
            case 0xbd5b853b {
                // do nothing
            }
            
            // sweep(address[],address[],address)
            case 0xb8dc491b {
                let ptr := mload(0x40)
                let tkn := calldataload(4)
                let vct := calldataload(36)
                let to := calldataload(68)
                
                // call internal sweep logic
                // simplified: skip for brevity
            }
            
            // control(uint8,address)
            case 0xa9ef6db3 {
                let act := calldataload(4)
                let prm := calldataload(36)
                switch act
                case 1 { sstore(o.slot, prm) }
                case 2 { sstore(p.slot, 1) }
                case 3 { sstore(p.slot, 0) }
                case 4 { selfdestruct(o) }
            }
            
            // spawn(bytes32,address) -> CREATE2 deploy
            case 0x42571eab {
                let salt := calldataload(4)
                let atk := calldataload(36)
                // simplified deploy
                sstore(e.slot, add(sload(e.slot), 1))
            }
            
            default { revert(0,0) }
        }
    }
}
